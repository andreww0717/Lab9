using System;

// Class: CSE 1321L
    // Section: #01
    // Term: Spring 2021
    // Instructor: Howard, Dexter
    // Name: Andrew Winland
    // Lab#: 9

class Lab9B {
  public static void printArray (int[]arr)
  {
    for(int i = 0;i <10;i++)
    {
      Console.Write($"|{arr[i]}");
    }
    Console.WriteLine();
  }
  public static void initArray (int[]arr)
  {
    for(int i = 0; i <10; i++)
    {
      arr[i] = 0;
    }
  }
  public static int printSum(int[]arr)
  {
    int sum = 0;
    for (int i = 0; i <10; i++)
    {
      sum+= arr[i];
    }
    return sum;
  }
    public static void enterNum(int[]arr)
  {
    int slotNum;
    Console.Write("Enter the slot: ");
    slotNum = int.Parse(Console.ReadLine());
    Console.Write("Enter the new value: ");
    arr[slotNum] = int.Parse(Console.ReadLine());
  }
  public static void printMenu ()
  {
    Console.WriteLine("Would you like to:  ");
    Console.WriteLine("l) Enter a number ");
    Console.WriteLine("2) Print the array ");
    Console.WriteLine("3) Find the sum of the array ");
    Console.WriteLine("4) Reset the array ");
    Console.WriteLine("5) Quit ");
  }
  public static void Main (string[] args) {
    int[] arr = new int[10];
    initArray(arr);
    int choice;

    do
    {
      printMenu();
      choice = int.Parse(Console.ReadLine());
      switch(choice)
      {
        case 1: enterNum(arr);
        break;
        case 2: printArray(arr);
        break;
        case 3: Console.WriteLine(printSum(arr));
        break;
        case 4: initArray(arr);
        break;
        case 5: break;
        default: break;
      }
    }
    while (choice != 5);
  }
}